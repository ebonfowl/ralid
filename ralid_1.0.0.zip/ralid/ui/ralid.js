(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data"},{"name":"vars","title":"Measures/raters (Time 1)","type":"Variables","suggested":["continuous"],"permitted":["numeric"]},{"name":"hasRetest","title":"Include re-test variables","type":"Bool","default":false},{"name":"varsRetest","title":"Re-test variables (Time 2; same order as Time 1)","type":"Variables","suggested":["continuous"],"permitted":["numeric"]},{"name":"eqLower","title":"TOST lower bound (difference scale)","type":"Number","default":-0.1},{"name":"eqUpper","title":"TOST upper bound (difference scale)","type":"Number","default":0.1},{"name":"confLevel","title":"Confidence level","type":"Number","default":0.95,"min":0.5,"max":0.999},{"name":"nBoot","title":"Bootstrap samples for CCC CI","type":"Integer","default":1000,"min":100,"max":10000},{"name":"includeClinLimits","title":"Include clinical limits on BA plot","type":"Bool","default":false},{"name":"clinicalLower","title":"Clinical lower limit (BA differences)","type":"Number","default":0},{"name":"clinicalUpper","title":"Clinical upper limit (BA differences)","type":"Number","default":0},{"name":"showBA","title":"Bland-Altman plot","type":"Bool","default":true},{"name":"baTrend","title":"Show trend line on BA plot","type":"Bool","default":false},{"name":"baTrendMethod","title":"Trend line type","type":"List","options":[{"name":"lm","title":"Linear regression"},{"name":"loess","title":"LOESS smooth"}],"default":"lm"},{"name":"overlayEquivRegion","title":"Overlay equivalence region on BA plot","type":"Bool","default":false},{"name":"showMountain","title":"Mountain plot","type":"Bool","default":true},{"name":"doTOST","title":"TOST equivalence test","type":"Bool","default":true},{"name":"showTOSTDecisionCurve","title":"Show TOST decision curve","type":"Bool","default":false},{"name":"showICC","title":"Compute ICCs (within time point)","type":"Bool","default":true},{"name":"showErrorMetrics","title":"Show error metrics table","type":"Bool","default":true},{"name":"doWithinSession","title":"Within-session repeatability","type":"Bool","default":false},{"name":"wsMeasure1","title":"Measure 1 trials","type":"Variables","suggested":["continuous"],"permitted":["numeric"]},{"name":"wsMeasure2","title":"Measure 2 trials","type":"Variables","suggested":["continuous"],"permitted":["numeric"]},{"name":"wsMeasure3","title":"Measure 3 trials","type":"Variables","suggested":["continuous"],"permitted":["numeric"]},{"name":"wsMeasure4","title":"Measure 4 trials","type":"Variables","suggested":["continuous"],"permitted":["numeric"]},{"name":"wsMeasure5","title":"Measure 5 trials","type":"Variables","suggested":["continuous"],"permitted":["numeric"]}];

const view = function() {
    
    this.handlers = { }

    View.extend({
        jus: "3.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Agreement, Equivalence & Reliability",
    jus: "3.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Measures/raters (Time 1)",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "vars",
							isTarget: true
						}
					]
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "hasRetest"
				}
			]
		},
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Re-test variables (Time 2; same order as Time 1)",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "varsRetest",
							isTarget: true
						}
					]
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "eqLower",
					format: FormatDef.number
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "eqUpper",
					format: FormatDef.number
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "confLevel",
					format: FormatDef.number
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "nBoot",
					format: FormatDef.number
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "includeClinLimits"
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "clinicalLower",
					format: FormatDef.number
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "clinicalUpper",
					format: FormatDef.number
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "showBA"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "baTrend"
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.ComboBox,
					typeName: 'ComboBox',
					name: "baTrendMethod"
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "overlayEquivRegion"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "showMountain"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "doTOST"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "showTOSTDecisionCurve"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "showICC"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "showErrorMetrics"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "doWithinSession"
				}
			]
		},
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Measure 1 trials",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "wsMeasure1",
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Measure 2 trials",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "wsMeasure2",
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Measure 3 trials",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "wsMeasure3",
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Measure 4 trials",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "wsMeasure4",
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Measure 5 trials",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "wsMeasure5",
							isTarget: true
						}
					]
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});
